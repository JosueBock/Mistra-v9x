After you have installed DVODE_F90 and run the two example programs
in the distribution file, you may wish to run the test program
'nonstiffoptions.f90' to test your installation. It solves each of
the test problems in the Toronto nonstiff test suite. It does this
for each of the scalar error tolerances 1.0D-4, 1.0D-6, 1.0D-8, and
1.0D-10. All results are written to a file named 'nonstiffoptions.dat.'
If after running the program, the last line of this file does not
read as follows: 'No errors occurred.', please contact one of the
authors.
